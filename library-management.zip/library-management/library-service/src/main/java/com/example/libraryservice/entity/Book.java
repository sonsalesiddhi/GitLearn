package com.example.libraryservice.entity;

import jakarta.persistence.*;

@Entity
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private String title;
    private String author;
    private String genre;

    @Column(unique = true)
    private String isbn;
    private Integer publicationYear;
    private Integer availableCopies;
}
