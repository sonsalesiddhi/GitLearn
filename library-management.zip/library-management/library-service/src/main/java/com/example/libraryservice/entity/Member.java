package com.example.libraryservice.entity;public class Member {
}
